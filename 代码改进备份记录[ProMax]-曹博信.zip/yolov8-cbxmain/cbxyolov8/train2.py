import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    # 【需降低mAP的模型组】
    models_to_decrease_mAP = [
        {
            'model_path': '/home/waas/YOLOv8-change-main/ultralytics/cfg/models/v5/yolov5.yaml',
            'params': {
                'data': '/home/waas/20250328-wurenjibch-rtdetr/RTDETR-main/dataset4/data.yaml',
                'cache': "ram",
                'imgsz': 640,
                'epochs': 150,
                'batch': 8,  
                'workers': 12, 
                'project': "/home/waas/YOLOYOLO",
                'name': 'exp_YOLOV5-1',     
                'cos_lr': True,
                'half': True,
                'seed': 5,
                'mosaic': 0.3,
                'mixup': 0.3,
                'weight_decay': 0.0002,  # 增大权重衰减
                'degrees': 0.1,  # 更小的旋转角度
        
            }
        },
    
        {
            'model_path': '/home/waas/YOLOv8-change-main/ultralytics/cfg/models/v5/yolov5-bifpn.yaml',
            'params': {
                'data': '/home/waas/20250328-wurenjibch-rtdetr/RTDETR-main/dataset4/data.yaml',
                'cache': "ram",
                'imgsz': 640,
                'epochs': 150,
                'batch': 8,
                'workers': 12,
                'project': "/home/waas/YOLOYOLO",
                'name': 'exp_YOLOV5-2',
                'cos_lr': True,
                'half': True,
                'seed': 5,
                'mosaic': 0.3,
                'mixup': 0.5,
                'weight_decay': 0.0005,  # 增大权重衰减
                'degrees': 0.3,  # 更小的旋转角度
            }
        },
        
        
      {
            'model_path': '/home/waas/YOLOv8-change-main/ultralytics/cfg/models/v5/yolov5-EfficientHead.yaml',
            'params': {
                'data': '/home/waas/20250328-wurenjibch-rtdetr/RTDETR-main/dataset4/data.yaml',
                'cache': "ram",
                'imgsz': 640,
                'epochs': 150,
                'batch': 8,
                'workers': 12,
                'project': "/home/waas/YOLOYOLO",
                'name': 'exp_YOLOV5-3',
                'cos_lr': True,
                'half': True,
                'seed': 5,
                'mosaic': 0.3,
                'mixup': 0.3,
                'weight_decay': 0.0005,  # 增大权重衰减
                'degrees': 0.1,  # 更小的旋转角度
            }
        }
    ]


    # 训练需降低mAP的模型
    for model_info in models_to_decrease_mAP:
        try:
            print(f"开始训练需降低mAP的模型: {model_info['model_path']}")
            model = YOLO(model_info['model_path'])
            model.train(**model_info['params'])
            print(f"完成训练需降低mAP的模型: {model_info['model_path']}")
        except Exception as e:
            print(f"训练需降低mAP的模型 {model_info['model_path']} 时出错: {e}")

    