import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO
"""
Module: personal_info
Author: Boxin Cao
Email: cbx2018cn@foxmail.com
Website: https://caobo.xin
Version: 3.1.9
Python Version: >= 3.8
License: MIT License 

Copyright (c) 2023  By CaoBoxin
All rights reserved.

"""

# -*- coding: utf-8 -*-
if __name__ == '__main__':
    model = YOLO( r'F:/2025YOLOV8test/yolov8cbx-main/cbxyolov8/ultralytics/cfg/models/v8/yolov8.yaml')
    model.load(r'F:/2025YOLOV8test/yolov8cbx-main/cbxyolov8/yolov8n.pt') # loading pretrain weights
    model.train(data=r'F:/2025YOLOV8test/yolov8cbx-main/cbxyolov8/dataset/data.yaml',
                cache='ram',
                imgsz=640,
                epochs=10,
                batch=8,
                close_mosaic=10,
                workers=4,
                device='0',
                optimizer='SGD', # using SGD
                amp=False,
                project='cbxyolov8/runs/train',
                name='exp',
                half=False,
                val=True
                )
